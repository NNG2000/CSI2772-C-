#pragma once
#include <iostream>
#include <vector>
//#using namespace std;
#include "Table.h"


void main() {
	bool game = true;
	char save;
	string gagnant, joueur2, joueur1;
	joueur1 = "premier";
	joueur2 = "deuxieme";
	Table* table = new Table(joueur1, joueur2);;
	while (game) {
		//setup
		cout << "Voulez-vous commenzer une nouvelle partie ? (o ou n)" << endl;
		cin >> save;
		//input players, initialization of deck, draw 5 cards from each hand
		if (save == 'o') {
			game = false;
			string joueur1;
			cout << "Veuillez inserer le nom du premier joueur: " << endl;
			cin >> joueur1;
			cout << "Veuillez inserer le nom du deuxieme joueur: " << endl;
			cin >> joueur2;
			table = new Table(joueur1, joueur2);
			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 5; j++) {
					table->joueurs[i] += table->deck->draw();
				}
			}
		}
		//load paused game
		else {
			CardFactory* factory = CardFactory::getFactory();
			ifstream saved("Bohnanza.txt");
			if (saved.is_open()) {
				game = false;
				table = new Table(saved, factory);

			}
			else
				cout << "Il n'y a aucune partie sauvegardee" << endl;
		}
	}

	//while there are still cards
	while (!table->win(gagnant)) {
		cout << "Voulez-vous sauver le jeu et quitter? (o ou n)" << endl;
		char reponse;
		cin >> reponse;
		//if pause save game to file
		if (reponse == 'o') {
			ofstream save("Bohnanza.txt");
			if (save) {
				table->joueurs[0].print(save);
				table->joueurs[1].print(save);
				(*table->pile).print(save);
				save << "\n" << *table->trade;
				save << "\n" << *table->deck << endl;
				save.close();
			}
			return;
		}
		else {
			//for each player
			for (int i = 0; i < 2; i++) {
				Player& joueur = table->joueurs[i];
				//display table
				cout << *table << "\n";
				cout << "Votre main: " << *joueur.getHand() << endl;
				//player draws top card
				joueur += table->deck->draw();
				//if trade area is not empty
				if (!table->trade->cartes->empty()) {
					char reponse;
					int i = 0;
					bool jeter = true;

					while (i < table->trade->types.size()) {
						string sorte = table->trade->sorteR(i);
						cout << *table << "\n";
						cout << "Voulez-vous ajouter les cartes de la sorte " << sorte << " ? (o ou n) " << endl;
						cin >> reponse;
						if (reponse == 'o') {
							Card* carte = table->trade->trade(sorte);
							while (carte != nullptr) {

								if (joueur.ajouterC(carte)) {
									carte = table->trade->trade(sorte);
								}
								else {
									bool next = false;
									bool echanger = true;
									bool possible = true;
									char reponse = ' ';
									if (joueur.getMaxNumChains() < 3) {
										cout << "Voulez-vous acheter une nouvelle chaine? (o ou n) " << endl;
										cin >> reponse;
										if (reponse == 'o') {
											try {
												joueur.buyThirdChain();
												echanger = false;
												next = true;
											}
											catch (NotEnoughCoins e) {
												cout << "Vous n'avez pas assez d'argent pour acheter une nouvelle chaine." << "\n";
											}
										}
									}
									if (echanger) {
										if (possible) {
											cout << "Voulez-vous echanger l'une de vos chaine? (o ou n) " << endl;
											cin >> reponse;
										}
										else {
											cout << "Veuillez vendre une chaine pour la remplacer.\n" << endl;
										}
										if (reponse == 'o' || !possible) {
											next = true;
											bool valid = false;
											int chaine;
											for (int i = 0; i < joueur.getNumChains(); i++)
												cout << "Chaine " << i + 1 << " de type " << joueur[i] << endl;
											while (!valid) {
												cout << endl << "Veuillez entrer le numero de la chaine que vous voulez echanger : ";
												cin >> chaine;
												if (!(0 < chaine && chaine <= joueur.getNumChains())) {
													cout << "Le numero est invalide. ";
													valid = false;
												}
											}
											chaine--;
											joueur.numCoins += joueur.chains[chaine].sell();
											joueur.chains.removeChain(chaine);
										}
									}

									if (!next) {
										carte = nullptr;
										i++;
									}
								}

							}
							i--;
						}
						else if (jeter) {
							Card* carte = table->trade->trade(sorte);
							while (carte) {
								(*table->pile) += carte;
								carte = table->trade->trade(sorte);
							}
							cout << "Le type " << sorte << " a ete mis dans la pile au rebut " << endl << endl;
							i--;

						}
						i++;
					}


					cout << *table << "\n";
				}
				else {
					cout << *table << "\n";
					cout << "Votre main: " << *joueur.getHand() << endl;
				}




				cout << "Jeu de la premiere carte de votre main: " << *joueur.getHand()->top() << "\n";
				bool continu = true;
				while (continu) {
					Card* topcard = joueur.getHand()->play();
					if (joueur.ajouterC(topcard)) {
						for (int i = 0; i < joueur.getNumChains(); i++) {
							if (joueur[i].sell() > 0) {
								joueur.numCoins += joueur.chains[i].sell();
								joueur.chains.removeChain(i);
								cout << "Chaine vendue" << endl;
								cout << *table << "\n";
							}
						}
					}

					else {
						bool next = false;
						bool echanger = true;
						bool possible = true;
						char reponse = ' ';
						if (joueur.getMaxNumChains() < 3) {
							cout << "Voulez-vous acheter une nouvelle chaine? (o ou n) " << endl;
							cin >> reponse;
							if (reponse == 'o') {
								try {
									joueur.buyThirdChain();
									echanger = false;
									next = true;
								}
								catch (NotEnoughCoins e) {
									cout << "Vous n'avez pas assez d'argent pour acheter une nouvelle chaine." << "\n";
								}
							}
						}
						if (echanger) {
							if (possible) {
								cout << "Voulez-vous echanger l'une de vos chaine? (o ou n) " << endl;
								cin >> reponse;
							}
							else {
								cout << "Veuillez vendre une chaine pour la remplacer.\n" << endl;
							}
							if (reponse == 'o' || !possible) {
								next = true;
								bool valid = false;
								int chaine;
								for (int i = 0; i < joueur.getNumChains(); i++)
									cout << "Chaine " << i + 1 << " de type " << joueur[i] << " " << endl;
								while (!valid) {
									cout << endl << "Veuillez entrer le numero de la chaine que vous voulez echanger : ";
									cin >> chaine;
									valid = true;
									if (!(0 < chaine && chaine <= joueur.getNumChains())) {
										cout << "Le numero est invalide. ";
										valid = false;
									}
								}
								chaine--;
								joueur.numCoins += joueur.chains[chaine].sell();
								joueur.chains.removeChain(chaine);
							}
						}
						joueur.ajouterC(topcard);

					}


					if (joueur.getHand()->size() > 0) {
						cout << joueur << endl;
						cout << "Votre main: " << *joueur.getHand() << endl;
						cout << "Voulez-vous jouer la deuxieme carte " << joueur.getHand()->top() << "  ? " << " (o ou n) " << endl;
						cin >> reponse;
						if (reponse == 'n' || (joueur.getHand()->size() == 0))
							continu = false;
					}

					if (joueur.getHand()->size() > 0) {
						//discard an arbitrairy card from the players hand
						cout << joueur << endl << "Votre main: " << *joueur.getHand() << "\n";
						cout << "Voulez-vous jeter une carte arbitraire? (o ou n) " << endl;
						cin >> reponse;
						if (reponse == 'o') {
							cout << endl << *joueur.getHand() << "\n";

							bool valid = false;
							int position;
							while (!valid) {
								cout << "Veuillez indiquer la position de la carte a jeter: " << endl;
								cin >> reponse;
								valid = true;
								position = reponse - '0';
								if (!(position <= joueur.getHand()->size() && 0 < position)) {
									cout << "Le numero est invalide. " << endl;
									valid = false;
								}
							}
							(*table->pile) += (*joueur.getHand())[position];
						}
					}
					//draw three cards from the deck and place in trade area
					for (int i = 0; i < 3; i++) {
						(*table->trade) += table->deck->draw();
					}
					while (!(table->pile->size() == 0) && table->trade->legal(table->pile->top())) {
						(*table->trade) += table->pile->pickUp();
					}

					char reponse;
					int i = 0;
					bool jeter = false;

					while (i < table->trade->types.size()) {
						string sorte = table->trade->sorteR(i);
						cout << *table << "\n";
						cout << "Voulez-vous ajouter les cartes de la sorte " << sorte << " ? (o ou n) " << endl;
						cin >> reponse;
						if (reponse == 'o') {
							Card* carte = table->trade->trade(sorte);
							while (carte != nullptr) {
								if (joueur.ajouterC(carte)) {
									carte = table->trade->trade(sorte);
								}
								else {
									bool next = false;
									bool echanger = true;
									bool possible = true;
									char reponse = ' ';
									if (joueur.getMaxNumChains() < 3) {
										cout << "Voulez-vous acheter une nouvelle chaine? (o ou n) " << endl;
										cin >> reponse;
										if (reponse == 'o') {
											try {
												joueur.buyThirdChain();
												echanger = false;
												next = true;
											}
											catch (NotEnoughCoins e) {
												cout << "Vous n'avez pas assez d'argent pour acheter une nouvelle chaine." << "\n";
											}
										}
									}
									if (echanger) {
										if (possible) {
											cout << "Voulez-vous echanger l'une de vos chaine? (o ou n) " << endl;
											cin >> reponse;
										}
										else {
											cout << "Veuillez vendre une chaine pour la remplacer.\n" << endl;
										}
										if (reponse == 'o' || !possible) {
											next = true;
											bool valid = false;
											int chaine;
											for (int i = 0; i < joueur.getNumChains(); i++)
												cout << "Chaine " << i + 1 << " de type " << joueur[i] << " " << endl;
											while (!valid) {
												cout << endl << "Veuillez entrer le numero de la chaine que vous voulez echanger : ";
												cin >> chaine;
												if (!(0 < chaine && chaine <= joueur.getNumChains())) {
													cout << "Le numero est invalide. ";
													valid = false;
												}
											}
											chaine--;
											joueur.numCoins += joueur.chains[chaine].sell();
											joueur.chains.removeChain(chaine);
										}
									}

									if (!next) {
										carte = nullptr;
										i++;
									}
								}

							}
							i--;
						}
						else if (jeter) {
							Card* carte = table->trade->trade(sorte);
							while (carte) {
								(*table->pile) += carte;
								carte = table->trade->trade(sorte);
							}
							cout << "Le type " << sorte << " a ete mis dans la pile au rebut " << endl << endl;
							i--;

						}
						i++;
					}
					for (int i = 0; i < 2; i++)
						joueur += table->deck->draw();
				}
			}
		}
	}
	cout << gagnant << " est le gagnant de la partie" << endl;
	remove("Bohnanza.txt");
	system("pause");
	return;
}