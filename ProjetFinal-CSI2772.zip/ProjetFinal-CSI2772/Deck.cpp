#include "Deck.h"


Deck::Deck(CardFactory* factory)
{
	*this = (*factory).getDeck();
}

ostream& operator<<(ostream& out, Deck deck) {
	for (vector<Card*>::iterator j = deck.begin(); j != deck.end(); j++) {
		out << (*j);
	}
	return out;
}

Deck::Deck(istream& in, CardFactory* factory)
{
	*this = factory->setDeck(in);
}

Card* Deck::draw()
{
	if (this->empty()) {
		return nullptr;
	}
	else {
		Card* draw = (*this).back();
		(*this).pop_back();
		return draw;
	}
}

