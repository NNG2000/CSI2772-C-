#include "Player.h"
#include "Deck.h"
#include "DiscardPile.h"
#include "TradeArea.h"
#include "CardFactory.h"
#include <iostream>
#include <fstream>

class Table {
public:
	vector<Player> joueurs;
	Deck *deck;
	DiscardPile *pile;
	TradeArea *trade;

public:
	Table(string& joueur1, string& joueur2)
	{
		Player player1(joueur1); Player player2(joueur2);
		joueurs.push_back(player1);	joueurs.push_back(player2);
		trade = new TradeArea(); pile = new DiscardPile();
		CardFactory* factory = CardFactory::getFactory();
		deck = new Deck(factory);
	};

	bool win(string& gagnant)
	{
		if (joueurs[0].getNumCoins() >= joueurs[1].getNumCoins())
			gagnant = joueurs[0].getName();
		else
			gagnant = joueurs[1].getName();
		return deck->empty();
	};

	friend ostream & operator << (ostream & out, Table table)
	{
		out << "*******Table*******\n";
		for (Player player : table.joueurs) {
			out << player << endl;
		}
		out << "Dessus de la pile au rebut :\n" << *table.pile << endl;
		out<< "En echange :\n" << *table.trade << endl;
		out << "*******************"<<endl;
		return out;
	};

	Table(istream& in, CardFactory* factory)
	{
		Player* joueur1 = new Player(in, factory);Player* joueur2 = new Player(in, factory);
		joueurs.push_back(*joueur1);joueurs.push_back(*joueur2);
		trade = new TradeArea(); pile = new DiscardPile();
		deck = new Deck(in, factory);

	};

};