#include "CardFactory.h"


CardFactory::CardFactory() {
	Card* nouvelle;
	deck = new Deck();
	for (int i = 0; i < 20; i++)
	{
		nouvelle = new Blue();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 18; i++)
	{
		nouvelle = new Chili();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 16; i++)
	{
		nouvelle = new Stink();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 14; i++)
	{
		nouvelle = new Green();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 12; i++)
	{
		nouvelle = new soy();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 10; i++)
	{
		nouvelle = new black();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 8; i++)
	{
		nouvelle = new Red();
		deck->push_back(nouvelle);
	}
	for (int i = 0; i < 6; i++)
	{
		nouvelle = new garden();
		deck->push_back(nouvelle);
	}

}

CardFactory* CardFactory::getFactory()
{
	static CardFactory cf;
	return &cf;
}

Deck CardFactory::setDeck(istream& old)
{
	int i = 0;
	deck = new Deck();
	char sorte[300];
	char sort;
	old.getline(sorte, 300);
	while (sorte[i] != NULL) {
		Card* ajouter = NULL;
		sort = sorte[i];
		if (sort == 'B') {
			ajouter = new Blue();
		}
		else if (sort == 'C') {
			ajouter = new Chili();
		}
		else if (sort == 'S') {
			ajouter = new Stink();
		}
		else if (sort == 'G') {
			ajouter = new Green();
		}
		else if (sort == 's') {
			ajouter = new soy();
		}
		else if (sort == 'b') {
			ajouter = new black();
		}
		else if (sort == 'R') {
			ajouter = new Red();
		}
		else if (sort == 'g') {
			ajouter = new garden();
		}
		deck->push_back(ajouter);
		i++;
	}

	return *deck;

}

Deck CardFactory::getDeck()
{
	random_shuffle(deck->begin(), deck->end());

	return *deck;
}

