#pragma once
#include "CardFactory.h"

class Hand : public vector<Card*> {
private:


public:
	Hand() = default;						
	Hand& operator+=(Card* carte)
	{
		(*this).insert(begin(), carte);
		return *this;

	};


	Card* play()
	{
		Card* carte = (*this).back();
		(*this).pop_back();
		return carte;
	};


	Card* top()
	{
		return (*this).back();
	};


	Card* operator[](int i)
	{
		Card* carte = (*this).at((*this).size() - i);
		(*this).erase((*this).begin() + ((*this).size() - i));
		return carte;
	};

	friend ostream& operator << (ostream& out, Hand main)
	{
		for (vector<Card*>::reverse_iterator i = main.rbegin(); i != main.rend(); i++) {
			out << (*i);
		}
		return out;
	};
	
	
	Hand(istream& in, CardFactory* factory)
	{
		char sorte[300];
		//in.getline(sorte, 300); 
		in.getline(sorte, 300);

		int j = 0;
		while (sorte[j] != NULL) {
			j++;
		}
		j--;
		char sort;
		for (int i = j; i >= 0; i--) {
			Card* ajouter = NULL;
			sort = sorte[i];
			if (sort == 'B') {
				ajouter = new Blue();
			}
			else if (sort == 'C') {
				ajouter = new Chili();
			}
			else if (sort == 'S') {
				ajouter = new Stink();
			}
			else if (sort == 'G') {
				ajouter = new Green();
			}
			else if (sort == 's') {
				ajouter = new soy();
			}
			else if (sort == 'b') {
				ajouter = new black();
			}
			else if (sort == 'R') {
				ajouter = new Red();
			}
			else if (sort == 'g') {
				ajouter = new garden();
			}

			(*this).push_back(ajouter);
		}

	};
};


