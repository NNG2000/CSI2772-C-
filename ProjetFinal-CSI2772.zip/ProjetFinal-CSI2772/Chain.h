﻿#include "ChainBase.h"
#include <vector>
#include "CardFactory.h"


template <class T> class Chain : public ChainBase, public vector<T*> {
public:
	string sorte;
	void print(ostream& out) const { out << (*this); };
	Chain()
	{
		T temp;
		sorte = temp.getName();
	};

	friend ostream& operator << (ostream& out, Chain<T> chaine) {
		out << chaine.getType() << '\t';

		if (chaine.getSize() > 0) {
			for (int i = 0; i < chaine.getSize(); i++)
				out << chaine.getType().at(0);
		}

		return out;
	};

	Chain(istream& in, CardFactory* factory)
	{

		string chaine;
		getline(in, chaine, '\t');
		char sorte[300];
		in.getline(sorte, 300);

		while (sorte != NULL) {
			if (sorte != ' ') {
				Card* ajouter = ((*factory).getCard(sorte));
				(*this).push_back(ajouter);
			}
			i++;
		}

	};

	bool legal(Card* carte){	return (sorte.compare((*carte).getName()) == 0);	};

	Chain<T>& operator+= (Card* carte)
	{

		if (legal(carte)) {
			T* comp = new T();
			this->push_back(comp);
		}
		else {
			throw sorteIncompatible();
		}

		return *this;
	};
	void addCard(Card* carte) { (*this) += carte; };

	int sell()
	{
		T objet;
		for (int i = 4; i > 0; i--) {
			if (this->getSize() >= objet.getCardsPerCoin(i)) {
				return i;
			}
		}

		return 0;
	};

	
	
	int getSize() { return this->size(); };
	string getType() { return sorte; };
	
};

class sorteIncompatible : public exception
{
	virtual const char* what() const throw()
	{
		return "Les deux sortes de cartes ne correspondent pas.";
	}
};




