
#pragma once 
#include <random>
#include "Deck.h"
#include "Card.h"


class Deck;

class CardFactory {
private:
	Deck *deck;
	CardFactory(const CardFactory&);
	CardFactory();

public:
	static CardFactory* getFactory();
	Deck getDeck();
	Deck setDeck (istream &);
};


