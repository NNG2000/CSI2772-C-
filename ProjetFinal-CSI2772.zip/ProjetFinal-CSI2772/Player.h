#include <string>
#include <iostream>
#include "CardFactory.h"
#include <exception>
#include "Chain.h"
#include "Hand.h"

using namespace std;

class NotEnoughCoins : public exception
{
	virtual const char* what() const throw()
	{
		cout << "Vous n'avez pas assez d'argent pour acheter une nouvelle chaine." << "\n";
		return NULL;
	}

	friend ostream& operator << (ostream& out, NotEnoughCoins e) {
		out << e.what();
		return out;
	}

};




class ChainContainer {
	int numero;
	ChainBase* premiere; ChainBase* deuxieme; ChainBase* troiseme;

public:
	ChainContainer() {
		numero = 0;
		premiere = NULL;
		deuxieme = NULL;
		troiseme = NULL;
	};

	ChainBase & ChainContainer:: operator[](int i) {
		if (0 <= i && i < numero) {
			if (i == 0)
				return *premiere;
			if (i == 1)
				return *deuxieme;
			return *troiseme;
		}	
		
	};

	ChainBase& back() {
		return (*this)[numero - 1];
	};

	bool ajouterChaine(ChainBase* chaine) {
		if (numero == 3)
			return false;
		if (numero == 0)
			premiere = chaine;
		if (numero == 1)
			deuxieme = chaine;
		if (numero == 2)
			troiseme = chaine;
		numero++;
		return true;
	};

	int size() { 
		return numero;
	};

	bool removeChain() {
		if (numero == 0)
			return false;
		if (numero == 1)
			premiere = NULL;
		if (numero == 2)
			deuxieme = NULL;
		if (numero = 3)
			troiseme = NULL;
		numero--;
		return true;
	};

	bool removeChain(int i) {

		if (0 <= i && i < numero) {
			if (i == 0) {
				premiere = deuxieme;
				deuxieme = troiseme;
			}
			if (i <= 1) {
				deuxieme = troiseme;
			}
			troiseme = NULL;
			numero--;
			return true;
		}
		
	};
};

class Player {

public:
	string nom;
	int numCoins;
	int maxNumChains;
	ChainContainer chains;
	Hand* main;

	Player(std::string& joueur)
	{										
		nom = joueur; maxNumChains = 2; numCoins = 0;
		main = new Hand();
	};

	string getName() { return nom; };

	int getNumCoins() { return numCoins; };

	Player& operator+=(int i) 
	{
		numCoins = numCoins + i;
		return(*this);
	};

	Player& operator+=(Card* carte)
	{
		*main += carte;
		return *this;
	};

	int getMaxNumChains() { return maxNumChains; };

	int getNumChains() { return chains.size(); };

	ChainBase& operator[](int i)
	{
		if (i < getNumChains())
			return chains[i];
	};

	void buyThirdChain()
	{
		if (numCoins < 3)
			throw NotEnoughCoins();
		else {
			numCoins = numCoins - 3; maxNumChains++;
		}

	};	

	void printHand(ostream& out, bool dessus)
	{
		if (dessus)
			out << *main;
		else
			out << main->top();
	};
																	
	void print(ostream& out)
	{
		out << getName() << '\t' << getNumCoins() << ' ' << getMaxNumChains() << "\n";
		out << *main << "\n";
		for (int i = 0; i < 3; i++) {
			if (i < getNumChains())
				out << chains[i].getType().at(0) << " " << chains[i].getSize() << "\n";
			else
				out << "NULL" << "\n";
		}

	};

	Player(istream& in, CardFactory* factory)
	{
		getline(in, nom, '\t');

		in >> numCoins;
		in >> maxNumChains;
		main = new Hand(in, factory);
		char sort;
		int size;
		string chainInfo;
		string tmp;
		for (int i = 0; i < 3; i++) {
			getline(in, chainInfo);
			if (chainInfo.compare("NULL") != 0) {
				sort = chainInfo.at(0);
				size = atoi(chainInfo.substr(2).c_str());
				if (sort == 'B') {
					ChainBase* newChain = new Chain<Blue>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'C') {
					ChainBase* newChain = new Chain<Chili>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'S') {
					ChainBase* newChain = new Chain<Stink>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'G') {
					ChainBase* newChain = new Chain<Green>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 's') {
					ChainBase* newChain = new Chain<soy>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'b') {
					ChainBase* newChain = new Chain<black>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'R') {
					ChainBase* newChain = new Chain<Red>;
					chains.ajouterChaine(newChain);
				}
				else if (sort == 'g') {
					ChainBase* newChain = new Chain<garden>;
					chains.ajouterChaine(newChain);
				}
				
				for (int i = 0; i < size; i++) {
					Card* ajouter = NULL;
					if (sort == 'B') {
						ajouter = new Blue();
					}
					else if (sort == 'C') {
						ajouter = new Chili();
					}
					else if (sort == 'S') {
						ajouter = new Stink();
					}
					else if (sort == 'G') {
						ajouter = new Green();
					}
					else if (sort == 's') {
						ajouter = new soy();
					}
					else if (sort == 'b') {
						ajouter = new black();
					}
					else if (sort == 'R') {
						ajouter = new Red();
					}
					else if (sort == 'g') {
						ajouter = new garden();
					}
					ajouterC(ajouter);
				}
			}
		}
	};

	friend ostream & operator << (ostream & out, Player joueur)
	{
		out << joueur.getName() << '\t' << joueur.getNumCoins() << " coins\n";
		for (int i = 0; i < joueur.getNumChains(); i++)
			out << joueur[i] << "\n";
		return out;
	};


	template<class T> bool chaine()
	{
		static_assert(std::is_base_of<Card, T>::value, "T is not derived from Card");
		if (chains.size() <= maxNumChains) {
			T temp;
			chaine(temp.getName()[0]);
			return true;
		}
		//else
		return false;
	};


	bool ajouterC(Card* carte)
	{
		if (carte != nullptr)
		{
			for (int i = 0; i < chains.size(); i++) {
				if ((*this)[i].legal(carte)) {
					(*this)[i] += carte;
					return true;
				}
			}
		}

		if (chains.size() < maxNumChains) {
			if (carte->getName()[0] == 'B') {
				ChainBase* newChain = new Chain<Blue>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'C') {
				ChainBase* newChain = new Chain<Chili>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'S') {
				ChainBase* newChain = new Chain<Stink>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'G') {
				ChainBase* newChain = new Chain<Green>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 's') {
				ChainBase* newChain = new Chain<soy>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'b') {
				ChainBase* newChain = new Chain<black>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'R') {
				ChainBase* newChain = new Chain<Red>;
				chains.ajouterChaine(newChain);
			}
			else if (carte->getName()[0] == 'g') {
				ChainBase* newChain = new Chain<garden>;
				chains.ajouterChaine(newChain);
			}
			chains.back() += carte;
			return true;
		}
		return false;
	}

	Hand* getHand() { return main; }

};
