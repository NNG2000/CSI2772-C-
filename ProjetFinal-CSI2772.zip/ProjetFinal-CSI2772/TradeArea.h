#include "Card.h"
#include <vector>
#include <list>
#include <iostream>
#include "CardFactory.h"

class TradeArea {
public:
	list<Card*>* cartes;
	list<string> types;
	TradeArea()
	{
		cartes = new list<Card*>;	types = list<string>();
	};

	TradeArea& operator += (Card* carte)
	{
		(*cartes).insert((*cartes).begin(), carte);
		bool poser = find(types.begin(), types.end(), carte->getName()) != types.end();
		if (!poser) {
			types.emplace_front(carte->getName());
		}
		return *this;
	};


	bool legal(Card* carte)
	{
		return (cartes->size() < 3 || std::find(types.begin(), types.end(), carte->getName()) != types.end() );
	};

	Card* trade(string sorte)
	{
		if (cartes->empty())
			return nullptr;
		list<Card*>::iterator i = cartes->begin();
		while (i != cartes->end()) {
			if (sorte.compare((**i).getName()) == 0) {
				Card* carte = *i;
				cartes->erase(i);
				bool present =false;
				list<Card*>::const_iterator debut = (*cartes).begin();
				list<Card*>::const_iterator fin = (*cartes).end();
				while (debut != fin) {
					++debut;
					if ((*debut)->getName().compare(sorte) == 0) 
						present=true;
				}
				if (!present) {
					types.remove(sorte);
				}
				return carte;
			}
			i++;
		}
		return nullptr;
	};

	int numCards() { return cartes->size(); };

	friend ostream & operator << (ostream & out, TradeArea trade)
	{
		for (list<Card*>::iterator i = trade.cartes->begin(); i != trade.cartes->end(); i++) {
			out << (*i);
		}
		return out;

	};


	TradeArea(istream& in, CardFactory* factory)
	{
		cartes = new list<Card*>;
		types = list<string>();
		char sorte[300];
		in.getline(sorte, 300);
		int j = 0;
		while (sorte[j] != NULL) {
			j++;
		}
		j--;
		for (int i = j; i >= 0; i--) {
			Card* ajouter = NULL;
			char sort = sorte[i];
			if (sort == 'B') {
				ajouter = new Blue();
			}
			else if (sort == 'C') {
				ajouter = new Chili();
			}
			else if (sort == 'S') {
				ajouter = new Stink();
			}
			else if (sort == 'G') {
				ajouter = new Green();
			}
			else if (sort == 's') {
				ajouter = new soy();
			}
			else if (sort == 'b') {
				ajouter = new black();
			}
			else if (sort == 'R') {
				ajouter = new Red();
			}
			else if (sort == 'g') {
				ajouter = new garden();
			}
			(*this) += ajouter;
		}

	};

	string sorteR(int j)
	{
		list<string>::iterator i = types.begin();
		while (j > 0 && i != types.end()) {
			i++; j--;
		}
		return *i;
	};
};