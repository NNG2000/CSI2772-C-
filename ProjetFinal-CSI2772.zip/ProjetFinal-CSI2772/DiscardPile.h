#include "CardFactory.h"
#include <vector>

class DiscardPile : public vector<Card*> {
public:
	DiscardPile() {};

	DiscardPile& operator+= (Card* carte)
	{
		(*this).push_back(carte);
		return *this;
	};

	Card* pickUp()
	{
		if ((*this).size() == 0) {
			return nullptr;
		}
		else {
			Card* temp = (*this).back();
			(*this).pop_back();
			return temp;
		}
	};

	Card* top() 
	{
		return this->back();
	};

	void print(ostream& out)
	{
		if (!(*this).size() == 0) {
			for (vector<Card*>::iterator it = this->begin(); it != this->end(); it++) {
				out << (**it);
			}
		}
	};


	friend ostream & operator << (ostream & out, DiscardPile pile)
	{
		if (!pile.size() == 0) {
			out << pile.back();
		}

		return out;
	};


	DiscardPile(istream& in, CardFactory* factory)
	{
		char sorte[300];
		in.getline(sorte, 300);
		int j = 0;
		while (sorte[j] != NULL) {
			j++;
		}
		j--;
		char sort;
		for (int i = j; i >= 0; i--) {
			Card* ajouter = NULL;
			sort = sorte[i];
			if (sort == 'B') {
				ajouter = new Blue();
			}
			else if (sort == 'C') {
				ajouter = new Chili();
			}
			else if (sort == 'S') {
				ajouter = new Stink();
			}
			else if (sort == 'G') {
				ajouter = new Green();
			}
			else if (sort == 's') {
				ajouter = new soy();
			}
			else if (sort == 'b') {
				ajouter = new black();
			}
			else if (sort == 'R') {
				ajouter = new Red();
			}
			else if (sort == 'g') {
				ajouter = new garden();
			}
			(*this).push_back(ajouter);
		}

	};
};