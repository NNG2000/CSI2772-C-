#include "Card.h"


class ChainBase {
public:
	virtual void addCard(Card*) = 0;
	virtual void print(ostream&) const = 0;
	virtual bool legal(Card*) = 0;
	virtual int sell() = 0;
	virtual int getSize() = 0;
	virtual string getType() = 0;
	friend ostream & operator << (ostream & out, const ChainBase& base) {
		base.print(out);
		return out;
	};
	ChainBase& operator+= (Card* carte) {
		this->addCard(carte);
		return *this;
	};
};