#pragma once

#include "Card.h"
#include <vector>
#include "CardFactory.h"
class CardFactory;

class Deck : public vector<Card*> {
public:
	Deck() = default;
	Deck(istream&, CardFactory*);
	Deck(CardFactory* factory);
	Card* draw();
	friend ostream & operator << (ostream &, Deck);
};
