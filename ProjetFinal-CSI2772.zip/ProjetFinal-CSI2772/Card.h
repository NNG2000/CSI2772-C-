#pragma once 

#include <iostream>
#include <string>

using namespace std;

class Card {
public:
	virtual int getCardsPerCoin(int) = 0;
	virtual string getName() = 0;
	friend ostream& operator << (ostream& out, const Card& carte) {
		carte.print(out);
		return out;
	};
	virtual void print(ostream&) const = 0;
};

class Blue : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 4;
			break;
		case 2:
			return 6;
			break;
		case 3:
			return 8;
			break;
		case 4:
			return 10;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "Blue";
	}

	void print(ostream& out) const {
		out << "B";
	}
};

class Chili : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 3;
			break;
		case 2:
			return 6;
			break;
		case 3:
			return 8;
			break;
		case 4:
			return 9;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "Chili";
	}

	void print(ostream& out) const {
		out << "C";
	}
};

class Stink : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 3;
			break;
		case 2:
			return 5;
			break;
		case 3:
			return 7;
			break;
		case 4:
			return 8;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "Stink";
	}

	void print(ostream& out) const {
		out << "S";
	}
};

class Green : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 3;
			break;
		case 2:
			return 5;
			break;
		case 3:
			return 6;
			break;
		case 4:
			return 7;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "Green";
	}

	void print(ostream& out) const {
		out << "G";
	}
};

class soy : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 2;
			break;
		case 2:
			return 4;
			break;
		case 3:
			return 6;
			break;
		case 4:
			return 7;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "soy";
	}

	void print(ostream& out) const {
		out << "s";
	}
};

class black : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 2;
			break;
		case 2:
			return 4;
			break;
		case 3:
			return 5;
			break;
		case 4:
			return 6;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "black";
	}

	void print(ostream& out) const {
		out << "b";
	}
};

class Red : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {
		case 1:
			return 2;
			break;
		case 2:
			return 3;
			break;
		case 3:
			return 4;
			break;
		case 4:
			return 5;
			break;
		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "Red";
	}

	void print(ostream& out) const {
		out << "R";
	}
};

class garden : public Card {

public:
	
	int getCardsPerCoin(int coins) {
		switch (coins) {

		case 2:
			return 6;
			break;
		case 3:
			return 8;
			break;

		default:
			return 0;
			break;
		}
	}

	string getName() {
		return "garden";
	}

	void print(ostream& out) const {
		out << "g";
	}
};

